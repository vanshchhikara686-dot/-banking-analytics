# SQL Server Analysis

`banking_analytics_source.sql` contains the SQL analysis supplied with this project.

It includes descriptive queries, joins, aggregations, CTEs, window functions, transaction trends, customer-account analysis and loan-default summaries.

**Before execution:** inspect the imported SQL Server table names. The source script uses several singular/plural variants (for example `transaction`/`Transactions`, `CreditScore`/`Credit_Scores`, and `branch`/`Branches`). Update identifiers to match the actual database schema. The source script is preserved as supplied and is not claimed to be fully execution-validated.
