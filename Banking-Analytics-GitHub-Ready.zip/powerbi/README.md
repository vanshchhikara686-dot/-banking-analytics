# Power BI Report

`Banking_Analytics.pbix` is the Power BI report supplied with this project.

Open it in Power BI Desktop to explore the report. Export screenshots of the actual report pages to the `screenshots/` folder and add the corresponding image references to the root README.
