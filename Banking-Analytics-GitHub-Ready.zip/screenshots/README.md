# Dashboard screenshots

Add exported PNG screenshots of the Power BI report pages here. Use descriptive filenames such as `01_customer_overview.png` and embed them in the root README using relative paths.
